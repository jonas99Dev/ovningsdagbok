## mappstruktur

frontend/
├── src/
├── public/
├── cypress/
│ ├── e2e/ <-- Här lägger du dina tester
│ ├── fixtures/ <-- Exempeldata för tester (valfritt)
│ ├── support/ <-- Delad konfiguration för Cypress-tester
│ └── cypress.config.js <-- Cypress konfigurationsfil
├── node_modules/
├── package.json
├── package-lock.json
└── vite.config.ts
