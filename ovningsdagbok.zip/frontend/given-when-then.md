## 1. Given:

- Testet beskriver vad som finns från början: **"Det finns en logg som redan är sparad"**.
- Detta görs genom att använda `cy.intercept` för att mocka loggar från servern.

## 2. When:

- Här beskriver vi exakt vad användaren gör: **"Användaren klickar på redigera och ändrar loggen"**.

## 3. Then:

- Vi beskriver resultatet som förväntas: **"Den uppdaterade loggen visas korrekt i listan"**.
