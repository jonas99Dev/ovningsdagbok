## krav

för G

minimum 2 tabeller
