module.exports = {
  component: {
    devServer: {
      framework: "react",
      bundler: "vite",
    },
  },
};
