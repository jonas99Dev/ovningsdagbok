# test för tuning note

tests:

- 1. Sidan laddas (verifiera att sidan renderas).
- 2. Knappen syns på sidan.
- 3. Knappen går att trycka på.
- 4. Texten “Playing pitch tone” visas när knappen trycks.

Det är bra att inte testa om själva tonen spelas, eftersom det är svårare att testa ljud i frontend och ligger utanför testets huvudsakliga syfte.
